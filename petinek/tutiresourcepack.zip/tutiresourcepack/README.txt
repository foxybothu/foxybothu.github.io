I was copying models from NotroDan
Btw: Thanks xd